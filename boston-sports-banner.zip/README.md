# Boston Sports Banner for DAKboard

A horizontal, professional-looking banner for:

- Boston Red Sox
- Boston Celtics
- New England Patriots

Each team card displays:
- Live score and game status when a game is underway
- A recent final for several hours after a game
- The next three upcoming games
- Automatic refresh every 60 seconds

## Publish with GitHub Pages

1. Create a free GitHub account if needed.
2. Create a new **public** repository named `boston-sports-banner`.
3. Upload `index.html` to the repository.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, select:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/(root)**
6. Click **Save**.
7. GitHub will provide an address similar to:
   `https://YOUR-USERNAME.github.io/boston-sports-banner/`

## Add it to DAKboard

1. Edit your custom DAKboard screen.
2. Choose **Add Block → Website**.
3. Paste the GitHub Pages address.
4. Stretch it across the full bottom width.
5. Start with a height around **130–150 px**, then adjust based on viewing distance.
6. Turn off borders/background inside DAKboard if those options are enabled.

## Notes

- The page needs internet access to retrieve current sports data.
- It uses ESPN's publicly accessible site data endpoints. Those endpoints are not a guaranteed developer product and could change in the future.
- Team logos are loaded from ESPN's image CDN.
